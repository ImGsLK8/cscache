const express = require('express');
const app = express();
app.use(express.static(__dirname + '/app'));
app.listen(4080, () => {
  console.log('Cubie Water Mark On');
});