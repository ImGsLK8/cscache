const express = require('express');
const app = express();
const { body, validationResult } = require('express-validator'); // Validate

const cookieSession = require('cookie-session'); 

const path = require("path");

// Import our other files
const { submit, getAll, deleteOne, deleteAll, getOne } = require('./form');
const { login, isLoggedIn, logout, deleteAuth } = require('./login');

const config = require('./config');

app.engine('html', require('ejs').renderFile); 
app.set('view engine', 'html');
app.use(express.urlencoded({
  extended: true
}));
app.set('views', path.join(__dirname, "/views/")); 
app.use(express.static(path.join(__dirname, '/public/'))); 
app.use(express.json()); // JSON!!!!!!!! 😂
app.set('trust proxy', 1); 
 
app.use(cookieSession({
  name: 'CubieStore', 
  keys: ['Cubie']
}));


app.get('/', (req, res) => {
  res.render('contact.html', {
    name: config.name,
  });
});


app.post('/',
body('email').isEmail().isLength({ max: 60 }),
body('message').not().isEmpty().trim().escape().isLength({ max: 2000 }),
body('name').not().isEmpty().trim().escape().isLength({ max: 50 }),
(req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() }); 
  }


  submit({
    email: req.body.email,
    name: req.body.name,
    message: req.body.message
  }, function() {
    res.sendStatus(200); 
  });
});


app.get('/admin', isLoggedIn /* Cubie */, async (req, res) => {
  // Get all submissions
  getAll(function(result) {
    res.render("admin.html", {
      all: result,
      name: config.name
    });
  });
});


app.post('/login', login);
app.post('/logout', logout);


app.post('/delete', deleteAuth, (req, res) => {
  deleteOne(req.body.key, () => {
    res.sendStatus(200);
  });
});


app.use((req, res) => {
  res.sendStatus(404);
});


app.listen(8080, () => {
  console.clear();
  console.log("[CubieForm]: Online");
});
