$(".password").on('keypress',function(e) {
  if(e.which == 13) {
    $.ajax({
      url: "/login",
      type: "post",
      data: {
        password: $(".password").val()
      },
      success: function(message) {
        location.reload();
      },
      error: function(message) {
        notifications("Senha inválida", "error");
      }
    });
  }
});
