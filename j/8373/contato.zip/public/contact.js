$(".submit").click(function() { // Once you click the submit button
  // Get value of inputs
  const email = $(".email").val();
  const name = $(".name").val();
  const message = $(".message").val();

  const checkResult = check(email, name, message); // Validate the form
  if(checkResult.length > 0) { // Check if there are errors
    // Make it grammatical
    if(checkResult.length === 1) { // 1 error
      notifications(capitalize(checkResult[0]), "error");
    }
    else { // Multiple errors
      // Create our grammatical error string
      if(checkResult.length === 2) { // "and" without a comma
        notifications(capitalize(checkResult[0]) + " and " + checkResult[1], "error");
      }
      else {
        let res = capitalize(checkResult[0]) + ", ";
        for (let blah = 1; blah < checkResult.length; blah++) {
          if(blah === checkResult.length - 1) { // This is the last error
            res += "and " + checkResult[blah] + ".";
          }
          else
            res += checkResult[blah] += ", ";
        }
        notifications(res, "error");
      }
    }
  }
  else {
    // Send AJAX request to submit form
    $.ajax({
      url: "/", // POST destination is home route
      type: "post", // Request type is POST
      data: { // POST the info
        email: email,
        name: name,
        message: message
      },
      success: function(message) {
        notifications("Submitted!", "success");
        $(".message").val("");
        $(".email").val("");
        $(".name").val("");
      },
      error: function(message) {
        notifications("Não foi possível enviar a mensagem", "error"); 
      }
    });
  }
});


function check(email, name, message) {
  let errors = []; // Array if errors
  if(email == "") {
    errors.push("E-mail Vazio");
  }
  if(name == "") {
    errors.push("Nome Vazio");
  }
  if(message == "") {
    errors.push("Sem Assunto Definido");
  }
  if(!validateEmail(email)) {
    if(!errors.includes("Email Vazio")) // 
      errors.push("E-mail Vazio");
  }
  if(email.length > 60) {
    errors.push("Seu e-mail é muito grande...");
  }
  if(name.length > 50) {
    errors.push("Nome muito grande...");
  }
  if(message.length > 3000) {
    errors.push("Sua mensagem é muito longa");
  }
  return errors;
}



function validateEmail(email) {
  const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(String(email).toLowerCase()); 
}


function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}
