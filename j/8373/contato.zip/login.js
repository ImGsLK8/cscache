const config = require("./config");
const password = config.password; 


exports.isLoggedIn = (req, res, next) => {
  if(req.session.blah === password) { 
    next();
  } else {
    res.render("login.html");
  }
}


exports.login = (req, res) => {
  if(req.body.password === password) {
    req.session.blah = password; 
    res.sendStatus(200);
  }
  else
    res.sendStatus(401); 
}

exports.logout = (req, res) => {
  req.session.blah = null; 
  res.redirect("/admin"); 
}


exports.deleteAuth = (req, res, next) => {
  if(req.session.blah === password) {
    next();
  } else
    res.sendStatus(401);
}
