module.exports = {
  name: "Seu Nome",
  password: "oi" //process.env.PASSWORD, 
};
